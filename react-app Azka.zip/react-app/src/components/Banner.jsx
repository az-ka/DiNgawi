import React from "react";

const Banner = () => {
    return (
        <div>
            <div>
                <img
                    src="/public/img/bg.png"
                    alt=""
                    className="h-[450px] w-full object-cover object-top"
                />
            </div>
        </div>
    );
};

export default Banner;
